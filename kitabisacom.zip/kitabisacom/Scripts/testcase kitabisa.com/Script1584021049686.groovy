import static com.kms.katalon.core.checkpoint.CheckpointFactory.findCheckpoint
import static com.kms.katalon.core.testcase.TestCaseFactory.findTestCase
import static com.kms.katalon.core.testdata.TestDataFactory.findTestData
import static com.kms.katalon.core.testobject.ObjectRepository.findTestObject
import static com.kms.katalon.core.testobject.ObjectRepository.findWindowsObject
import com.kms.katalon.core.checkpoint.Checkpoint as Checkpoint
import com.kms.katalon.core.cucumber.keyword.CucumberBuiltinKeywords as CucumberKW
import com.kms.katalon.core.mobile.keyword.MobileBuiltInKeywords as Mobile
import com.kms.katalon.core.model.FailureHandling as FailureHandling
import com.kms.katalon.core.testcase.TestCase as TestCase
import com.kms.katalon.core.testdata.TestData as TestData
import com.kms.katalon.core.testobject.TestObject as TestObject
import com.kms.katalon.core.webservice.keyword.WSBuiltInKeywords as WS
import com.kms.katalon.core.webui.keyword.WebUiBuiltInKeywords as WebUI
import com.kms.katalon.core.windows.keyword.WindowsBuiltinKeywords as Windows
import internal.GlobalVariable as GlobalVariable

WebUI.openBrowser('https://www.kitabisa.com')

WebUI.delay(2)

WebUI.scrollToElement(findTestObject('PilihCampaign'), 0)

WebUI.delay(2)

WebUI.click(findTestObject('img_Bantu siapa hari ini_style__ListImageCanvas-sc-1sl4ulh-3 cTDNTQ'))

WebUI.delay(3)

WebUI.click(findTestObject('button_DONASI SEKARANG'))

WebUI.delay(3)

WebUI.click(findTestObject('div_Rp 10000Nominal minimal donasi'))

WebUI.delay(3)

WebUI.scrollToElement(findTestObject('div_Transfer BCA'), 0)

WebUI.delay(3)

WebUI.click(findTestObject('div_Transfer BCA'))

WebUI.delay(3)

WebUI.setText(findTestObject('input_atau lengkapi data di bawah ini_fullname'), 'Adelia Indah')

WebUI.setText(findTestObject('input_Nama lengkap tidak boleh kosong_username'), '081221303462')

WebUI.delay(3)

WebUI.click(findTestObject('button_LANJUTKAN PEMBAYARAN'))

WebUI.delay(3)

WebUI.click(findTestObject('span_Sisa hari_style__BannerCloseIcon-sc-106sadj-2 kCModS'))

WebUI.delay(3)

WebUI.click(findTestObject('button_KEMBALI KE PENGGALANGAN'))

WebUI.delay(3)

WebUI.click(findTestObject('backarrow_home'))

WebUI.delay(3)

